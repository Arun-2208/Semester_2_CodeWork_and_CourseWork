import java.util.Scanner;

/**
 * Demonstrates class methods (static methods) in the Math class.
 *
 * @author Robyn Gibson
 * @version 1.1 (March 2014)
 */
public class L3MathUsageStart {

    public static void main(String[] args)  {
        int myBooks;
        int yourBooks;
        int smaller;
        int difference;
        double pizzaDiam;
        double pizzaArea;
        Scanner sc = new Scanner(System.in);

        System.out.print("How many books do you have? ");
        yourBooks = sc.nextInt();
        System.out.print("How many books do you think I have? ");
        myBooks = sc.nextInt();
        //TASK 1: Which is the smaller number, the number of your books or my books?

        //TASK 2: Calculate the difference between the number of books I have and the number of books you have


        System.out.print("Enter the diameter of your pizza: ");
        pizzaDiam = sc.nextDouble();
        //TASK 3: Calculate the area of a family size pizza
    }
}
