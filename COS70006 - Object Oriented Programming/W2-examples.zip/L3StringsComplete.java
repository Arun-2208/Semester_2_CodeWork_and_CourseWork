/**
 * Demonstrates declaration of reference variables, instantiation of String
 * objects, calling methods and using return values.
 *
 * @author Robyn Gibson
 *
 * @version 2.1 (March 2014)
 */
public class L3StringsComplete {

    public static void main(String []  args) {
        int len, pos;               // primitive variables
        char letter1, letter2;      // primitive variables
        boolean same;               // primitive variables
        String word1, word2, word3; // reference variables
        String sub1, sub2;          // reference variables

        word1 = new String("hello");   //instantiation
        word2 = new String("there");   //instantiation
        word3 = new String("hello"); //instantiation
        len = word3.length();
        System.out.println("word1 is " + word1);
        System.out.println("The length of word3 is " + len);

        //Find the first letter of word1
        letter1 = word1.charAt(0);
        System.out.println("first letter in word1: " + letter1);
        //Find the position of the first 'r' in word3
        letter2 = 'r';
        pos = word3.indexOf(letter2);
        System.out.println("where the 'r' is in word3: " + pos);
        //Check if word1 and word3 represent the same string
        same = word1.equals(word3);
        System.out.println("word1 and word3 contain the same string?: " + same);
        //extract the first 4 letters of word1
        sub1 = word1.substring(0, 4);
        System.out.println("first 4 letters of word1: " + sub1);
        //extract the last 3 letters of word3
        sub2 = word3.substring(len - 3, len);
        System.out.println("last 3 letters of word3: " + sub2);

    }

}
