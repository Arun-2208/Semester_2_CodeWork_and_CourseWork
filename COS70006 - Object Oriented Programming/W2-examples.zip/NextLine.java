import java.util.Scanner;

/**
 * This demonstrate the working of nextLine(): Advances this scanner past the current line and returns the input that was skipped.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NextLine
{
	public static void main (String[] args)
	{
		int input;
		String reply;
		Scanner sc = new Scanner(System.in);

		System.out.println("Please enter a whole number ");
		input = sc.nextInt();

		sc.nextLine();  //if you comment out this line, you won't have a chance to respond to the following question

		System.out.println("Is " + input +" what you just entered (yes/no)?");
		reply = sc.nextLine();

		System.out.println("Program finished!");
	}
}