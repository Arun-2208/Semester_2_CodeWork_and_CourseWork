/**
 * Demonstrates declaration of reference variables, instantiation of String
 * objects, calling methods and using return values.
 *
 * @author Robyn Gibson
 *
 * @version 2.1 (March 2014)
 */
public class L3StringsStart {

    public static void main(String[] args) {
        int len, pos;               // primitive variables
        char letter1, letter2;      // primitive variables
        boolean same;               // primitive variables
        String word1, word2, word3; // reference variables
        String sub1, sub2;          // reference variables

        word1 = new String("hello");   //instantiation
        word2 = new String("there");   //instantiation
        word3 = new String("friends"); //instantiation
        len = word3.length();
        System.out.println("word1 is " + word1);
        System.out.println("The length of word3 is " + len);

        //TASKS: Add code to
        //1. Find/display the first letter of word1
        letter1 = word1.charAt(0);
        System.out.println("the first letter of word1 is " + letter1);

        //2. Find the position of the first 'r' in word3
        letter2 = 'r';
        pos = word3.indexOf(letter2);
        System.out.println("the position of \"r\" in word3 is " + pos);

        //3. Check if word1 and word3 represent the same string
        //4. Extract the first 4 characters (that is, a String of length 4) from word1
        //5. Extract the last 3 characters of word3
    }

}
