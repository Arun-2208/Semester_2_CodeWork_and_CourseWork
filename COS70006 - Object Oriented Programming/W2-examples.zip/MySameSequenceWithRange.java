import java.util.Random;
/**
 *Some times we need to generate same random number sequence everytime
 *we call the sequence generator method on every call. We cannot achieve this
 *if we use simple Random() class constructor.
 *We need to pass seed to the Random() constructor to generate same random sequence.
 *The below example, calls the generateSequence() method three times, and generates the same random sequence.

 */
public class MySameSequenceWithRange {

    public void generateSequence(){
        Random rnd = new Random(40); //see is 40 in this case

        for(int i=0;i<5;i++){
            System.out.println(rnd.nextInt(100));  //generate a number from 0 inclusive to 100 exclusive)
        }
    }

    public static void main(String a[]){
        MySameSequenceWithRange mss = new MySameSequenceWithRange();
        mss.generateSequence();
        System.out.println("====================");
        mss.generateSequence();
        System.out.println("====================");
        mss.generateSequence();
    }
}
