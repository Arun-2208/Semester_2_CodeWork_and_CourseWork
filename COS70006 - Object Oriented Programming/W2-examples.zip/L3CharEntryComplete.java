import java.util.Scanner;

/**
 * Demonstrate how to combine the abilities of a Scanner (which reads numbers
 * and strings from standard input) with methods of the String class in order
 * to read a single character.
 *
 * @author Robyn Gibson
 * @version 1.1 (March 2014)
 */
public class L3CharEntryComplete {

    public static void main(String[] args) {
        Scanner sc;
        char letter;
        String temp;

        sc = new Scanner(System.in);

        System.out.print("Please enter a single character: ");
        temp = sc.next();
        letter = temp.charAt(0);
        System.out.println("Letter you entered entered was " + letter);
    }

}
