import java.util.Scanner;

/**
 * Demonstrates class methods (static methods) in the Math class.
 *
 * @author Robyn Gibson
 * @version 1.1 (March 2014)
 */
public class L3MathUsageComplete {

    public static void main(String[] args) {
        int myBooks;
        int yourBooks;
        int smaller;
        int difference;
        double pizzaDiam;
        double pizzaArea;
        Scanner sc = new Scanner(System.in);

        System.out.print("How many books do you have? ");
        yourBooks = sc.nextInt();
        System.out.print("How many books do you think I have? ");
        myBooks = sc.nextInt();

        smaller = Math.min(myBooks,yourBooks);
        System.out.println("The smaller of thes two numbers is: " + smaller);
        difference = Math.abs(yourBooks - myBooks);
        System.out.println("The difference between these is: " + difference);

        System.out.print("Enter the diameter of your pizza: ");
        pizzaDiam = sc.nextDouble();

        pizzaArea = Math.PI * Math.pow(pizzaDiam/2,2);
        System.out.println("The area of this pizza is: " + pizzaArea + " square whatevers");

    }
}
